# MakerNest Origins: the sketches

The Arduino library for The Maker's Book of Origins, and every chapter's sketch.

Where each sketch lives:
- Chapters 01 and 02: printed in the book (pages 11 and 22). The maker types them in. The library carries the same two as examples, identical to the print.
- Chapter 03 to the Gift: only on the chapter pages (makernest.com/origins/03 to /12, /d, /g) and from Milo. They are not in the library, so the Examples menu can't be used to skip Milo, and a sketch can be changed without a library release. These files are in the folder "Milo sketches".

MakerNest Origins is a brand of Innointel Global Private Limited.

## Install

1. In the Arduino IDE, open Library Manager. Search for MakerNest Origins and install it. When it asks to install other libraries too (U8g2, Adafruit NeoPixel, DHT sensor library), say yes.
2. Until the library is listed in Library Manager, install it from the zip instead: Sketch, Include Library, Add .ZIP Library. Then install the three other libraries from Library Manager by name.
3. Board: Arduino Uno. The kit's board needs the CH340 USB driver (makernest.com/origins/00).

## The sketches

| Sketch | Chapter | Screens on the dial, in order after the reading | What its loop() does |
|---|---|---|---|
| 01 First Light | 01 | none | Shows sensor A. If the yellow wire comes off, the last number stays and nothing complains. |
| 02 The Tripwire | 02 | WATCH BELOW, NORMAL COLOUR | First upload opens WATCH BELOW, then NORMAL COLOUR. Ring red below your number, your colour above it. |
| 03 The Noisemaker | 03 | NORMAL COLOUR, WHEN COLD, WATCH BELOW, TEST OUTPUTS | WHEN COLD is RING, BUZZER, BOTH or ALWAYS. ALWAYS keeps the buzzer on whatever happens. |
| 04 The Chatterbox | 04 | START, STOP AT, NORMAL COLOUR, WHEN COLD, TEST OUTPUTS | Starts below START, stops at STOP AT. Confirming START goes straight to STOP AT. Same numbers: it chatters. |
| 05 Sensor Duel | 05 | SHOUT IF APART BY, ALARM WATCHES, then 04's | Shows A and B. Orange and the buzzer when A and B are further apart than your gap. The cold rule watches A or B. |
| 06 The Witness | 06 | SETTLE, KEEP COUNT AFTER RESTART, then 05's | Counts door openings on D8 (built-in pull-up). SETTLE starts at 0 s, so a slow door counts twice. |
| 07 The Night Shift | 07 | WRITE EVERY, LOG, then 06's | Writes sensor A to the board's own memory every 10 s, 1 min, 15 min or 1 h. LOG moves one hour per click. |
| 08 Chain Reaction | 08 | SEQUENCE, RUN NOW, START WITH, then 07's | Three steps: what (NONE, RING, BUZZER, LAMP), how long, gap before. Never checks a step worked. Keeps 07's notebook. |
| D The Doorkeeper | flagship one | TOO MANY, LOG, SEQUENCE, RUN NOW, START WITH, START, STOP AT, SETTLE, KEEP COUNT, WRITE EVERY, SHOUT IF APART BY, ALARM WATCHES, NORMAL COLOUR, WHEN COLD, TEST OUTPUTS | Everything. Runs the sequence when openings in the last hour reach TOO MANY; re-arms when they fall back by your chapter 04 gap. Notebook writes A, B and openings. |
| 09 Stakeout | 09, and stays on for 10 and 11 | as D | As D. The display sleeps after 90 s to save the battery; the dial wakes it. |
| 12 Your Own Machine | 12 | START, STOP AT (add more) | The starter: every pin named, every setting readable, one example rule to change. |
| G The Gift | flagship two | as 12 | The same starter, for the Gift. |

No sketch shows an error message or a hint. A sensor that stops answering keeps its last number (the chapter 01 and fault 5 lessons).

## Rules every sketch keeps

- Settings live in the board's own memory (EEPROM) in one shared layout, so a number chosen in chapter 02 is still there in chapter 09. Uploading a new sketch never clears them.
- Hold the dial down and press the shield's reset button: every setting goes back to how it came. The notebook is kept.
- The notebook keeps its numbers through uploads and restarts. An upload sets the day and time from the computer. After a restart without an upload, the time continues from the last saved minute and LOG marks it with ~.
- The sensors are read every two seconds, which is the DHT22's limit. That is why chapter 04 chatters every couple of seconds.

## Memory map (1024 bytes)

| Bytes | What |
|---|---|
| 0 to 63 | Settings (OriginsSettings in MakerNestOrigins.h) |
| 64 to 71 | Notebook header: marker, wrap count, upload stamp, part count |
| 72 to 131 | Six notebook parts: first record, start time, interval, format |
| 132 to 195 | Sixteen saved times, one written every 10 minutes |
| 196 to 1023 | The notebook: 828 bytes, one byte per reading (0.25 °C steps) |

Notebook length: 10 s lasts 2 hours, 1 min 13 hours, 15 min 8 days, 1 h 34 days. Chapter 09 and D also write B and the door count, so each record is 3 bytes: 1 h lasts 11 days.

## Size on the UNO

Every sketch uses about 28 KB of 32 KB and 1 KB of 2 KB memory. Chapter 12 leaves about 4 KB for the maker's own code.

## Before release: bench test (lab)

1. Each sketch uploads and shows its name for two seconds. Chapters 03 onwards are opened from the Milo sketches folder (File, Open).
2. Dial direction: clockwise raises the number. If not, swap the CLK and DT wires, or swap the pins in the header.
3. Buzzer: quiet at rest. If it sounds at rest, set ORIGINS_BUZZER_ON to LOW in MakerNestOrigins.h.
4. Chapter 01: pull sensor A's yellow wire. The number freezes. Pull the display's red wire. The screen goes dark.
5. Chapter 04: STOP AT equal to START chatters about every 2 s near the line.
6. Chapter 06: a very slow opening adds 2 or 3 with SETTLE at 0, and 1 with SETTLE at 2.
7. Chapter 07: at 10 s the note bar visibly fills in a minute. Unplug and replug: the numbers are still in LOG.
8. Chapter 08: pull the 9 V clip during a run. Steps 1 and 2 run, step 3 does nothing, SEQUENCE DONE shows.
9. Hold the dial while pressing reset: settings return to how they came; LOG still has the week.
10. Chapter 09 on a full battery pack: note how many days it runs (book page 110).
