// MakerNest Origins engine. See MakerNestOrigins.h.
#include "MakerNestOrigins.h"
#include <EEPROM.h>
#include <U8x8lib.h>
#include <Adafruit_NeoPixel.h>
#include <DHT.h>

Origins machine;

static U8X8_SSD1306_128X64_NONAME_HW_I2C oled(U8X8_PIN_NONE);
static Adafruit_NeoPixel ringLeds(8, PIN_RING, NEO_GRB + NEO_KHZ800);
static DHT dhtA(PIN_SENSOR_A, DHT22);
static DHT dhtB(PIN_SENSOR_B, DHT22);

// ---------------------------------------------------------------- memory map (1024 bytes on the UNO)
static const int EE_SETTINGS = 0;      // 64 bytes
static const int EE_NB       = 64;     // notebook header: magic, wraps(2), upload stamp(4), segment count
static const int EE_SEG      = 72;     // 6 segments x 10 bytes
static const int EE_SLOT     = 132;    // 16 time slots x 4 bytes
static const int EE_DATA     = 196;    // the notebook itself
static const int NB_N        = 1024 - EE_DATA;   // 828 bytes
static const uint8_t NB_MAGIC = 0xA7, NB_SEGS = 6, SET_MAGIC = 0x5A;

struct Seg { uint32_t startSerial; uint32_t startSec; uint8_t every; uint8_t fmt; };   // fmt: bit0 B, bit1 events, bit7 time approximate

static const uint16_t EVERY_SEC_P[4] PROGMEM = { 10, 60, 900, 3600 };
#define EVERY_SEC(i) pgm_read_word(&EVERY_SEC_P[(i)])
static const char COLOUR_NAME_0[] PROGMEM = "GREEN";
static const char COLOUR_NAME_1[] PROGMEM = "BLUE";
static const char COLOUR_NAME_2[] PROGMEM = "WHITE";
static const char COLOUR_NAME_3[] PROGMEM = "PURPLE";
static const char COLOUR_NAME_4[] PROGMEM = "YELLOW";
static const char COLOUR_NAME_5[] PROGMEM = "OFF";
static const char COLOUR_NAME_6[] PROGMEM = "RED";
static const char COLOUR_NAME_7[] PROGMEM = "ORANGE";
static const char *const COLOUR_NAME[] PROGMEM = { COLOUR_NAME_0, COLOUR_NAME_1, COLOUR_NAME_2, COLOUR_NAME_3, COLOUR_NAME_4, COLOUR_NAME_5, COLOUR_NAME_6, COLOUR_NAME_7 };
static const uint8_t COLOUR_RGB[][3] PROGMEM = { {0, 255, 40}, {0, 80, 255}, {255, 255, 255}, {160, 0, 255}, {255, 200, 0}, {0, 0, 0}, {255, 0, 0}, {255, 90, 0} };
static const char WHEN_NAME_0[] PROGMEM = "RING";
static const char WHEN_NAME_1[] PROGMEM = "BUZZER";
static const char WHEN_NAME_2[] PROGMEM = "BOTH";
static const char WHEN_NAME_3[] PROGMEM = "ALWAYS";
static const char *const WHEN_NAME[] PROGMEM = { WHEN_NAME_0, WHEN_NAME_1, WHEN_NAME_2, WHEN_NAME_3 };
static const char STEP_NAME_0[] PROGMEM = "NONE";
static const char STEP_NAME_1[] PROGMEM = "RING";
static const char STEP_NAME_2[] PROGMEM = "BUZZER";
static const char STEP_NAME_3[] PROGMEM = "LAMP";
static const char *const STEP_NAME[] PROGMEM = { STEP_NAME_0, STEP_NAME_1, STEP_NAME_2, STEP_NAME_3 };
static const char EVERY_NAME_0[] PROGMEM = "10 SEC";
static const char EVERY_NAME_1[] PROGMEM = "1 MIN";
static const char EVERY_NAME_2[] PROGMEM = "15 MIN";
static const char EVERY_NAME_3[] PROGMEM = "1 HOUR";
static const char *const EVERY_NAME[] PROGMEM = { EVERY_NAME_0, EVERY_NAME_1, EVERY_NAME_2, EVERY_NAME_3 };
static const char DAY_NAME_0[] PROGMEM = "MON";
static const char DAY_NAME_1[] PROGMEM = "TUE";
static const char DAY_NAME_2[] PROGMEM = "WED";
static const char DAY_NAME_3[] PROGMEM = "THU";
static const char DAY_NAME_4[] PROGMEM = "FRI";
static const char DAY_NAME_5[] PROGMEM = "SAT";
static const char DAY_NAME_6[] PROGMEM = "SUN";
static const char *const DAY_NAME[] PROGMEM = { DAY_NAME_0, DAY_NAME_1, DAY_NAME_2, DAY_NAME_3, DAY_NAME_4, DAY_NAME_5, DAY_NAME_6 };

static uint16_t nbHead = 0, nbWraps = 0;

// ---------------------------------------------------------------- small helpers
static uint8_t recSize(uint8_t fmt) { return 1 + (fmt & 1) + ((fmt >> 1) & 1); }
static uint8_t encodeT(float t) { int v = (int)((t + 10.0f) * 4.0f + 0.5f); if (v < 0) v = 0; if (v > 254) v = 254; return (uint8_t)v; }
static float decodeT(uint8_t v) { return v / 4.0f - 10.0f; }
static uint32_t nbTotal() { return (uint32_t)nbWraps * NB_N + nbHead; }
static uint8_t nbSegCount() { return EEPROM.read(EE_NB + 7); }
static void nbGetSeg(uint8_t i, Seg &s) { EEPROM.get(EE_SEG + i * 10, s); }

static uint8_t monthIndex(const char *m) {
  const char *names = "JanFebMarAprMayJunJulAugSepOctNovDec";
  for (uint8_t i = 0; i < 12; i++) if (strncmp(m, names + i * 3, 3) == 0) return i;
  return 0;
}
// seconds since Monday 1 Jan 2024, from the moment this sketch was compiled
static uint32_t compileSeconds() {
  const char *d = __DATE__;            // "Nov  1 2026"
  const char *t = __TIME__;            // "13:05:22"
  uint8_t mon = monthIndex(d);
  uint8_t day = atoi(d + 4);
  uint16_t year = atoi(d + 7);
  static const uint16_t cum[12] = { 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334 };
  uint32_t days = 0;
  for (uint16_t y = 2024; y < year; y++) days += ((y % 4) == 0) ? 366 : 365;
  days += cum[mon] + (day - 1);
  if (mon > 1 && (year % 4) == 0) days++;
  return days * 86400UL + atoi(t) * 3600UL + atoi(t + 3) * 60UL + atoi(t + 6) + 20;   // about 20 s to upload
}

// ---------------------------------------------------------------- dial interrupt (pins 3 and 4)
ISR(PCINT2_vect) { machine._dialEdge(); }
void Origins::_dialEdge() {
  static const int8_t table[16] = { 0, -1, 1, 0, 1, 0, 0, -1, -1, 0, 0, 1, 0, 1, -1, 0 };
  uint8_t p = PIND; uint8_t ab = (((p >> 3) & 1) << 1) | ((p >> 4) & 1);   // pins 3 and 4
  _dialState = ((_dialState << 2) | ab) & 0x0F;
  _dialSteps += table[_dialState];
}

// ---------------------------------------------------------------- begin
void Origins::begin(uint8_t chapter, const char *name) {
  _chapter = chapter; _name = name;
  pinMode(PIN_DIAL_CLK, INPUT_PULLUP); pinMode(PIN_DIAL_DT, INPUT_PULLUP); pinMode(PIN_DIAL_SW, INPUT_PULLUP);
  pinMode(PIN_BUZZER, OUTPUT); digitalWrite(PIN_BUZZER, !ORIGINS_BUZZER_ON);
  pinMode(PIN_LAMP, OUTPUT); digitalWrite(PIN_LAMP, LOW);
  pinMode(PIN_DOOR, INPUT_PULLUP);
  memset(_rowCache, 0, sizeof(_rowCache));
  memset(_minuteBuckets, 0, sizeof(_minuteBuckets));
  _screens[0] = SCR_HOME; _nScreens = 1;

  // Hold the dial down while the machine starts: every setting goes back to how it came. The notebook stays.
  delay(30);
  bool reset = digitalRead(PIN_DIAL_SW) == LOW;
  _loadSettings(reset);
  if (!settings.keepCount) { settings.count = 0; saveSettings(); }

  oled.begin(); oled.setPowerSave(0);
  ringLeds.begin(); ringLeds.setBrightness(48); ringLeds.clear(); ringLeds.show();
  dhtA.begin(); if (_chapter >= 5) dhtB.begin();

  PCICR |= (1 << PCIE2); PCMSK2 |= (1 << PCINT19) | (1 << PCINT20);
  _dialState = (digitalRead(PIN_DIAL_CLK) << 1) | digitalRead(PIN_DIAL_DT);

  _nbBegin();
  _doorLast = digitalRead(PIN_DOOR);

  // The chapter's name, for two seconds
  oled.setFont(u8x8_font_8x13B_1x2_r);
  oled.clear();
  {                                                    // up to three lines, split by |
    char line[9]; uint8_t row = 1, n = 0;
    for (const char *p = name; ; p++) {
      if (*p == '|' || *p == 0) { line[n] = 0; oled.drawString(0, row, line); row += 2; n = 0; if (!*p || row > 5) break; }
      else if (n < 8) line[n++] = *p;
    }
  }
  delay(2000);
  if (_chapter >= 7 && _chapter != 10 && _chapter != 11) {      // the day and time, for two seconds
    oled.clear();
    uint32_t s = _minuteNow;
    char t[9]; strcpy_P(t, (PGM_P)pgm_read_word(&DAY_NAME[(s / 86400UL) % 7]));
    oled.drawString(0, 2, t);
    snprintf_P(t, sizeof t, PSTR("%s%02u:%02u"), _timeApprox ? "~" : "", (unsigned)((s / 3600UL) % 24), (unsigned)((s / 60) % 60));
    oled.drawString(0, 5, t);
    delay(2000);
  }
  oled.clear();
  _lastInput = millis();
  _readSensors();
}

void Origins::useScreen(Screen s) { if (_nScreens < 16) _screens[_nScreens++] = s; }
void Origins::edit(Screen s) { for (uint8_t i = 0; i < _nScreens; i++) if (_screens[i] == s) { _cur = i; _startEdit(); return; } }
void Origins::homeShows(uint8_t what) { _home = what; }

// ---------------------------------------------------------------- settings
void Origins::_loadSettings(bool reset) {
  EEPROM.get(EE_SETTINGS, settings);
  if (reset || settings.magic != SET_MAGIC || settings.layout != 1) {
    uint32_t keep = (settings.magic == SET_MAGIC && !reset) ? settings.count : 0;
    memset(&settings, 0, sizeof settings);
    settings.magic = SET_MAGIC; settings.layout = 1;
    settings.coldLine = NOT_SET; settings.stopAt = NOT_SET;
    settings.normalColour = 255; settings.whenCold = WHEN_RING;
    settings.keepCount = 1; settings.count = keep;
    settings.writeEvery = EVERY_15MIN;
    for (uint8_t i = 0; i < 3; i++) { settings.stepOut[i] = STEP_NONE; settings.stepFor[i] = 3; settings.stepGap[i] = 0; }
    saveSettings();
  }
}
void Origins::saveSettings() { EEPROM.put(EE_SETTINGS, settings); }

// ---------------------------------------------------------------- the loop
void Origins::update() {
  _readDial();
  _readButton();
  _readDoor();
  if (millis() - _lastSensor >= 2000) _readSensors();     // a DHT22 can only answer every two seconds
  _tickClock();
  _nbTick();
  _tickSequence();
  _tickOutputs();
  if (millis() - _lastDraw >= 250) _draw(false);
  if (_chapter == 9 && !_asleep && millis() - _lastInput > 90000UL) { oled.setPowerSave(1); _asleep = true; }   // saves the battery
}

void Origins::_readSensors() {
  _lastSensor = millis();
  float t = dhtA.readTemperature(), h = dhtA.readHumidity();
  if (!isnan(t)) { _tA = t; _gotA = true; }        // no reading: keep the last one, and say nothing
  if (!isnan(h)) _hA = h;
  if (_chapter >= 5) { float tb = dhtB.readTemperature(); if (!isnan(tb)) { _tB = tb; _gotB = true; } }
}

void Origins::_readDoor() {
  if (_chapter < 6) return;
  bool open = digitalRead(PIN_DOOR);                  // magnet near: switch closed: LOW. Door open: HIGH.
  uint32_t now = millis();
  if (open && !_doorLast && now >= _doorIgnoreUntil) {
    settings.count++;
    if (settings.keepCount) EEPROM.put(EE_SETTINGS + offsetof(OriginsSettings, count), settings.count);
    _doorIgnoreUntil = now + settings.settle * 1000UL;
    uint8_t m = (now / 60000UL) % 60;
    if (_minuteBuckets[m] < 255) _minuteBuckets[m]++;
    if (_eventsSinceRecord < 254) _eventsSinceRecord++;
  }
  _doorLast = open;
  uint8_t m = (now / 60000UL) % 60;
  if (m != _bucketMinute) { _bucketMinute = m; _minuteBuckets[m] = 0; }
}
uint8_t Origins::openingsInLastHour() { uint16_t s = 0; for (uint8_t i = 0; i < 60; i++) s += _minuteBuckets[i]; return s > 255 ? 255 : s; }

// ---------------------------------------------------------------- outputs
void Origins::ring(uint8_t colour) {
  if (_seqStep >= 0) return;                          // the sequence has the outputs while it runs
  if (colour >= COLOUR_COUNT) colour = RING_OFF;
  if (colour == _ringColour) return;
  _ringColour = colour;
  for (uint8_t i = 0; i < 8; i++) ringLeds.setPixelColor(i, pgm_read_byte(&COLOUR_RGB[colour][0]), pgm_read_byte(&COLOUR_RGB[colour][1]), pgm_read_byte(&COLOUR_RGB[colour][2]));
  ringLeds.show();
}
void Origins::buzzer(bool on) { if (_seqStep >= 0) return; _buzzSteady = on; if (on) _beep = false; }
void Origins::buzzerBeep(bool on) { if (_seqStep >= 0) return; _beep = on; if (on) _buzzSteady = false; }
void Origins::lamp(bool on) { if (_seqStep >= 0) return; digitalWrite(PIN_LAMP, on ? HIGH : LOW); }

void Origins::_tickOutputs() {
  if (_seqStep >= 0) return;
  bool b = _buzzSteady || (_beep && ((millis() / 300) % 2 == 0));
  digitalWrite(PIN_BUZZER, b ? ORIGINS_BUZZER_ON : !ORIGINS_BUZZER_ON);
}

// ---------------------------------------------------------------- sequence: gap, then the step, three times. It never checks.
void Origins::runSequence() {
  if (_seqStep >= 0) return;
  _seqStep = 0; _seqPhase = 0; _seqUntil = millis() + settings.stepGap[0] * 1000UL;
  digitalWrite(PIN_BUZZER, !ORIGINS_BUZZER_ON); digitalWrite(PIN_LAMP, LOW);
  ringLeds.clear(); ringLeds.show(); _ringColour = RING_OFF;
}
void Origins::_tickSequence() {
  if (_seqStep < 0) return;
  if (millis() < _seqUntil) return;
  uint8_t i = _seqStep;
  if (_seqPhase == 0) {                               // gap is over: start the step
    uint8_t o = settings.stepOut[i];
    if (o == STEP_RING) { for (uint8_t k = 0; k < 8; k++) ringLeds.setPixelColor(k, 255, 0, 0); ringLeds.show(); }
    if (o == STEP_BUZZER) digitalWrite(PIN_BUZZER, ORIGINS_BUZZER_ON);
    if (o == STEP_LAMP) digitalWrite(PIN_LAMP, HIGH);
    _seqPhase = 1; _seqUntil = millis() + settings.stepFor[i] * 1000UL;
  } else {                                            // step is over: stop it, move on
    ringLeds.clear(); ringLeds.show(); digitalWrite(PIN_BUZZER, !ORIGINS_BUZZER_ON); digitalWrite(PIN_LAMP, LOW);
    if (++_seqStep >= 3) { _seqStep = -1; _ringColour = 255; _doneUntil = millis() + 3000; }
    else { _seqPhase = 0; _seqUntil = millis() + settings.stepGap[_seqStep] * 1000UL; }
  }
}

// ---------------------------------------------------------------- the dial
void Origins::_readDial() {
  noInterrupts(); int16_t s = _dialSteps; interrupts();
  int16_t d = (s - _dialTaken) / 4;                   // four edges to one click
  if (d != 0) {
    _dialTaken += d * 4;
    _lastInput = millis(); if (_asleep) { oled.setPowerSave(0); _asleep = false; }
    while (d > 0) { _turn(1); d--; }
    while (d < 0) { _turn(-1); d++; }
  }
}
void Origins::_readButton() {
  bool up = digitalRead(PIN_DIAL_SW);
  uint32_t now = millis();
  if (up != _btnLast && now - _btnTime > 40) {
    _btnTime = now; _btnLast = up;
    if (!up) { _lastInput = now; if (_asleep) { oled.setPowerSave(0); _asleep = false; return; } _press(); }
  }
}

void Origins::_editLimits(Screen s, int16_t &lo, int16_t &hi) {
  lo = 0; hi = 0;
  switch (s) {
    case SCR_COLD_LINE:     lo = 0;  hi = 45; break;
    case SCR_NORMAL_COLOUR: lo = 0;  hi = RING_OFF; break;
    case SCR_WHEN_COLD:     lo = 0;  hi = 3; break;
    case SCR_STOP_AT:       lo = settings.coldLine == NOT_SET ? 0 : settings.coldLine; hi = 50; break;
    case SCR_APART_BY:      lo = 1;  hi = 20; break;
    case SCR_WATCHES:       lo = 0;  hi = 1; break;
    case SCR_SETTLE:        lo = 0;  hi = 10; break;
    case SCR_KEEP_COUNT:    lo = 0;  hi = 1; break;
    case SCR_WRITE_EVERY:   lo = 0;  hi = 3; break;
    case SCR_START_WITH:    lo = 0;  hi = 1; break;
    case SCR_TOO_MANY:      lo = 1;  hi = 50; break;
    case SCR_SEQUENCE: {
      uint8_t f = _seqEditIndex % 3;
      if (f == 0) { lo = 0; hi = 3; } else if (f == 1) { lo = 1; hi = 30; } else { lo = 0; hi = 60; }
      break; }
    default: break;
  }
}

void Origins::_startEdit() {
  Screen s = _screens[_cur];
  _editing = true;
  int16_t t = (int16_t)(_tA + 0.5f);
  switch (s) {
    case SCR_COLD_LINE:     _editValue = settings.coldLine == NOT_SET ? t : settings.coldLine; _untouched = settings.coldLine == NOT_SET; break;
    case SCR_NORMAL_COLOUR: _editValue = settings.normalColour == 255 ? (uint8_t)GREEN : settings.normalColour; ring(_editValue); break;
    case SCR_WHEN_COLD:     _editValue = settings.whenCold; break;
    case SCR_STOP_AT:       _editValue = settings.stopAt == NOT_SET ? (settings.coldLine == NOT_SET ? t : settings.coldLine) : settings.stopAt; break;
    case SCR_APART_BY:      _editValue = settings.apartBy ? settings.apartBy : 4; break;
    case SCR_WATCHES:       _editValue = settings.watches; break;
    case SCR_SETTLE:        _editValue = settings.settle; break;
    case SCR_KEEP_COUNT:    _editValue = settings.keepCount; break;
    case SCR_WRITE_EVERY:   _editValue = settings.writeEvery; break;
    case SCR_START_WITH:    _editValue = settings.startWith; break;
    case SCR_TOO_MANY:      _editValue = settings.tooMany ? settings.tooMany : 5; break;
    case SCR_SEQUENCE:      _seqEditIndex = 0; _editValue = settings.stepOut[0]; break;
    case SCR_LOG:           _logCursor = (int32_t)(_minuteNow / 3600UL) * 3600L; break;
    case SCR_RUN_NOW:       _editing = false; runSequence(); break;
    case SCR_TEST:          _editing = false;
                            ring(RED); digitalWrite(PIN_BUZZER, ORIGINS_BUZZER_ON); digitalWrite(PIN_LAMP, HIGH);
                            delay(1500);
                            digitalWrite(PIN_BUZZER, !ORIGINS_BUZZER_ON); digitalWrite(PIN_LAMP, LOW); _ringColour = 255; break;
    default: _editing = false; break;
  }
}

void Origins::_turn(int8_t d) {
  if (!_editing) {                                    // turning moves between screens
    _cur = (_cur + _nScreens + d) % _nScreens;
    return;
  }
  Screen s = _screens[_cur];
  if (s == SCR_LOG) { _logCursor += d * 3600L; return; }   // one hour per click
  if (_untouched) { _untouched = false; return; }        // the first click shows the number, from the room's own reading
  int16_t lo, hi; _editLimits(s, lo, hi);
  _editValue += d;
  if (s == SCR_NORMAL_COLOUR || s == SCR_WHEN_COLD || s == SCR_WRITE_EVERY || s == SCR_WATCHES || s == SCR_KEEP_COUNT || s == SCR_START_WITH ||
      (s == SCR_SEQUENCE && _seqEditIndex % 3 == 0)) {
    if (_editValue > hi) _editValue = lo;             // lists go round
    if (_editValue < lo) _editValue = hi;
  } else {
    if (_editValue > hi) _editValue = hi;
    if (_editValue < lo) _editValue = lo;
  }
  if (s == SCR_NORMAL_COLOUR) ring(_editValue);
}

void Origins::_press() {
  if (!_editing) { if (_screens[_cur] != SCR_HOME) _startEdit(); return; }
  _confirmEdit();
}

void Origins::_confirmEdit() {
  Screen s = _screens[_cur];
  if (_untouched) return;                             // nothing chosen yet: a press does nothing
  _editing = false;
  switch (s) {
    case SCR_COLD_LINE:
      settings.coldLine = _editValue;
      if (settings.stopAt != NOT_SET && settings.stopAt < settings.coldLine) settings.stopAt = settings.coldLine;
      saveSettings();
      // chapter 02, the first time: straight on to the ring's colour. From chapter 04: straight on to STOP AT.
      for (uint8_t i = 0; i < _nScreens; i++) {
        if (_chapter == 2 && settings.normalColour == 255 && _screens[i] == SCR_NORMAL_COLOUR) { _cur = i; _startEdit(); return; }
        if (_chapter >= 4 && _screens[i] == SCR_STOP_AT) { _cur = i; _startEdit(); return; }
      }
      break;
    case SCR_NORMAL_COLOUR: settings.normalColour = _editValue; _ringColour = 255; break;
    case SCR_WHEN_COLD:     settings.whenCold = _editValue; break;
    case SCR_STOP_AT:       settings.stopAt = _editValue; break;
    case SCR_APART_BY:      settings.apartBy = _editValue; break;
    case SCR_WATCHES:       settings.watches = _editValue; break;
    case SCR_SETTLE:        settings.settle = _editValue; break;
    case SCR_KEEP_COUNT:    settings.keepCount = _editValue; break;
    case SCR_WRITE_EVERY:   if (settings.writeEvery != _editValue) { settings.writeEvery = _editValue; saveSettings(); _nbBegin(); } break;
    case SCR_START_WITH:    settings.startWith = _editValue; break;
    case SCR_TOO_MANY:      settings.tooMany = _editValue; break;
    case SCR_SEQUENCE: {
      uint8_t i = _seqEditIndex / 3, f = _seqEditIndex % 3;
      if (f == 0) settings.stepOut[i] = _editValue; else if (f == 1) settings.stepFor[i] = _editValue; else settings.stepGap[i] = _editValue;
      if (++_seqEditIndex < 9) {                      // on to the next box: what, how long, gap before
        uint8_t j = _seqEditIndex / 3, g = _seqEditIndex % 3;
        _editValue = g == 0 ? settings.stepOut[j] : g == 1 ? settings.stepFor[j] : settings.stepGap[j];
        _editing = true;
      }
      break; }
    case SCR_LOG: break;                              // leaving the log
    default: break;
  }
  saveSettings();
  if (s == SCR_COLD_LINE || s == SCR_STOP_AT || s == SCR_NORMAL_COLOUR) _cur = 0;   // back to the reading
}

// ---------------------------------------------------------------- the display
void Origins::_row(uint8_t r, const char *t) {
  char buf[17]; memset(buf, ' ', 16); buf[16] = 0;
  size_t n = strlen(t); if (n > 16) n = 16; memcpy(buf, t, n);
  if (strcmp(buf, _rowCache[r]) == 0) return;
  strcpy(_rowCache[r], buf);
  oled.setFont(u8x8_font_chroma48medium8_r);
  oled.drawString(0, r, buf);
}
static void fmtT(char *o, float t) {
  int v = (int)(t * 10.0f + (t >= 0 ? 0.5f : -0.5f));
  int w = v / 10, f = abs(v % 10);
  if (v < 0 && w == 0) sprintf_P(o, PSTR("-0.%d"), f); else sprintf_P(o, PSTR("%d.%d"), w, f);
}
static void twoBy(uint8_t row, const char *t) {        // a line of tall text, two rows tall
  char buf[17]; memset(buf, ' ', 16); buf[16] = 0;
  size_t n = strlen(t); if (n > 16) n = 16; memcpy(buf, t, n);
  oled.setFont(u8x8_font_8x13B_1x2_r);
  oled.drawString(0, row, buf);
}
void Origins::_big(const char *t) {                    // a number, four rows tall
  char buf[7]; memset(buf, ' ', 6); buf[6] = 0;
  size_t n = strlen(t); if (n > 6) n = 6; memcpy(buf + (6 - n), t, n);
  oled.setFont(u8x8_font_inb21_2x4_n);
  oled.drawString(2, 2, buf);
}

void Origins::_draw(bool force) {
  _lastDraw = millis();
  static uint8_t lastKey = 255; static char lastBig[12] = "";
  Screen s = _screens[_cur];
  uint8_t key = s * 2 + (_editing ? 1 : 0);
  if (key != lastKey || force) { oled.clear(); memset(_rowCache, 0, sizeof(_rowCache)); lastBig[0] = 0; lastKey = key; }
  char a[12], b[17], c[17];

  if (s == SCR_HOME) {
    if (!(_home & SHOW_B) && !(_home & SHOW_COUNT)) {             // one big number
      if (_gotA) fmtT(a, _tA); else strcpy_P(a, PSTR("--.-"));
      if (strcmp(a, lastBig) != 0) { _big(a); strcpy(lastBig, a); }
      if (_home & SHOW_LINE) {
        if (_chapter < 4) { if (settings.coldLine == NOT_SET) strcpy_P(b, PSTR("WATCH BELOW")); else snprintf_P(b, 17, PSTR("WATCH BELOW %d"), settings.coldLine); }
        else snprintf_P(b, 17, PSTR("START %d STOP %d"), settings.coldLine == NOT_SET ? 0 : settings.coldLine,
                      settings.stopAt == NOT_SET ? (settings.coldLine == NOT_SET ? 0 : settings.coldLine) : settings.stopAt);
        _row(7, b);
      }
    } else {                                                       // A, B and the count, two rows each
      char k[17];
      fmtT(a, _tA); snprintf_P(k, 17, PSTR("A %s"), _gotA ? a : "--");
      if (strcmp(k, _rowCache[0]) != 0) { twoBy(0, k); strcpy(_rowCache[0], k); _rowCache[1][0] = 0; }
      if (_home & SHOW_B) {
        fmtT(a, _tB); snprintf_P(k, 17, PSTR("B %s"), _gotB ? a : "--");
        if (strcmp(k, _rowCache[2]) != 0) { twoBy(2, k); strcpy(_rowCache[2], k); _rowCache[3][0] = 0; }
      }
      if (_home & SHOW_COUNT) {
        snprintf_P(k, 17, PSTR("COUNT %lu"), (unsigned long)settings.count);
        if (strcmp(k, _rowCache[4]) != 0) { twoBy(4, k); strcpy(_rowCache[4], k); _rowCache[5][0] = 0; }
      }
      if (_home & SHOW_LINE) {
        snprintf_P(b, 17, PSTR("START %d STOP %d"), settings.coldLine == NOT_SET ? 0 : settings.coldLine,
                 settings.stopAt == NOT_SET ? (settings.coldLine == NOT_SET ? 0 : settings.coldLine) : settings.stopAt);
        _row(6, b);
      }
    }
    if (millis() < _doneUntil) _row(7, "SEQUENCE DONE");
    else if (_home & SHOW_NOTEBOOK) {
      uint8_t p = _nbFillPercent(), n = (p * 10 + 50) / 100; if (n > 10) n = 10;
      strcpy_P(b, PSTR("NOTE [")); for (uint8_t i = 0; i < 10; i++) strcat(b, i < n ? "#" : " "); strcat(b, "]");
      _row(7, b);
    } else if (!(_home & SHOW_LINE) || (_home & (SHOW_B | SHOW_COUNT))) _row(7, "");
    return;
  }

  // ---- a settings screen: its name on top, its value big, editing shown with arrows
  char nm[17] = "";
  int16_t v = _editing ? _editValue : 0;
  b[0] = 0; c[0] = 0;
  switch (s) {
    case SCR_COLD_LINE:     strcpy_P(nm, _chapter < 4 ? PSTR("WATCH BELOW") : PSTR("START"));
                            if (!_editing) v = settings.coldLine;
                            if (v == NOT_SET || (_editing && _untouched)) strcpy_P(b, PSTR("")); else snprintf_P(b, 9, PSTR("%d"), v); break;
    case SCR_NORMAL_COLOUR: strcpy_P(nm, PSTR("NORMAL COLOUR")); if (!_editing) v = settings.normalColour == 255 ? (uint8_t)GREEN : settings.normalColour; strcpy_P(b, (PGM_P)pgm_read_word(&COLOUR_NAME[v])); break;
    case SCR_WHEN_COLD:     strcpy_P(nm, PSTR("WHEN COLD")); if (!_editing) v = settings.whenCold; strcpy_P(b, (PGM_P)pgm_read_word(&WHEN_NAME[v])); break;
    case SCR_TEST:          strcpy_P(nm, PSTR("TEST OUTPUTS")); strcpy_P(b, PSTR("PRESS")); break;
    case SCR_STOP_AT:       strcpy_P(nm, PSTR("STOP AT")); if (!_editing) v = settings.stopAt; if (v == NOT_SET) strcpy_P(b, PSTR("")); else snprintf_P(b, 9, PSTR("%d"), v); break;
    case SCR_APART_BY:      strcpy_P(nm, PSTR("SHOUT IF APART BY")); if (!_editing) v = settings.apartBy;
                            if (v == 0) strcpy_P(b, PSTR("")); else snprintf_P(b, 9, PSTR("%d.%d"), v / 2, (v % 2) * 5); break;
    case SCR_WATCHES:       strcpy_P(nm, PSTR("ALARM WATCHES")); if (!_editing) v = settings.watches; strcpy_P(b, v ? PSTR("B") : PSTR("A")); break;
    case SCR_SETTLE:        strcpy_P(nm, PSTR("SETTLE")); if (!_editing) v = settings.settle; snprintf_P(b, 9, PSTR("%d SEC"), v); break;
    case SCR_KEEP_COUNT:    strcpy_P(nm, PSTR("KEEP COUNT AFTER")); strcpy_P(c, PSTR("RESTART")); if (!_editing) v = settings.keepCount; strcpy_P(b, v ? PSTR("YES") : PSTR("NO")); break;
    case SCR_WRITE_EVERY: { strcpy_P(nm, PSTR("WRITE EVERY")); if (!_editing) v = settings.writeEvery; strcpy_P(b, (PGM_P)pgm_read_word(&EVERY_NAME[v]));
                            uint16_t h = _nbLastsHours(v, _nbFormat());
                            if (h < 24) snprintf_P(c, 17, PSTR("LASTS %u HOURS"), h); else snprintf_P(c, 17, PSTR("LASTS %u DAYS"), h / 24);
                            break; }
    case SCR_LOG:           if (_editing) { _nbDrawLog(); return; } strcpy_P(nm, PSTR("LOG")); strcpy_P(b, PSTR("PRESS")); break;
    case SCR_SEQUENCE: {    strcpy_P(nm, PSTR("SEQUENCE"));
                            if (_editing) {
                              uint8_t i = _seqEditIndex / 3, f = _seqEditIndex % 3;
                              snprintf_P(c, 17, PSTR("STEP %u %s"), i + 1, f == 0 ? "WHAT" : f == 1 ? "HOW LONG" : "GAP BEFORE");
                              if (f == 0) strcpy_P(b, (PGM_P)pgm_read_word(&STEP_NAME[v])); else snprintf_P(b, 9, PSTR("%d SEC"), v);
                            } else {
                              { char x[3][8]; for (uint8_t q = 0; q < 3; q++) strcpy_P(x[q], (PGM_P)pgm_read_word(&STEP_NAME[settings.stepOut[q]])); snprintf_P(c, 17, PSTR("%s %s %s"), x[0], x[1], x[2]); }
                              strcpy_P(b, PSTR("PRESS"));
                            }
                            break; }
    case SCR_RUN_NOW:       strcpy_P(nm, PSTR("RUN NOW")); strcpy_P(b, _seqStep >= 0 ? PSTR("") : PSTR("PRESS")); break;
    case SCR_START_WITH:    strcpy_P(nm, PSTR("START WITH")); if (!_editing) v = settings.startWith; strcpy_P(b, v ? PSTR("COLD") : PSTR("NOTHING")); break;
    case SCR_TOO_MANY:      strcpy_P(nm, PSTR("TOO MANY")); if (!_editing) v = settings.tooMany; if (v == 0) strcpy_P(b, PSTR("")); else snprintf_P(b, 9, PSTR("%d"), v); break;
    default: break;
  }
  _row(0, nm);
  char k[17];
  if (_editing) snprintf_P(k, 17, PSTR("<%s>"), b); else snprintf_P(k, 17, PSTR(" %s"), b);
  if (strcmp(k, _rowCache[3]) != 0) { twoBy(3, k); strcpy(_rowCache[3], k); _rowCache[4][0] = 0; }
  _row(6, c);
  if (s == SCR_COLD_LINE || s == SCR_STOP_AT) { char t[8], r[17]; fmtT(t, _tA); snprintf_P(r, 17, PSTR("NOW %s"), _gotA ? t : "--"); _row(7, r); }
}

// ---------------------------------------------------------------- the clock: counts seconds from the upload
void Origins::_tickClock() {
  uint32_t now = millis();
  while (now - _millisAtMinute >= 1000) {             // _minuteNow holds seconds since 1 Jan 2024
    _millisAtMinute += 1000; _minuteNow++;
    if (_minuteNow % 600 == 0) EEPROM.put(EE_SLOT + ((_minuteNow / 600) % 16) * 4, _minuteNow);   // so a restart knows roughly what time it is
  }
}

// ---------------------------------------------------------------- the notebook
uint8_t Origins::_nbFormat() { return (_chapter == 9 || _chapter == 13) ? 3 : 0; }
uint16_t Origins::_nbLastsHours(uint8_t every, uint8_t fmt) {
  uint32_t recs = (NB_N - 1) / recSize(fmt);
  return (uint16_t)(recs * EVERY_SEC(every) / 3600UL);
}
uint8_t Origins::_nbFillPercent() { return nbWraps ? 100 : (uint8_t)((uint32_t)nbHead * 100 / NB_N); }

void Origins::_nbBegin() {
  static bool first = true;
  if (first) {
    first = false;
    if (EEPROM.read(EE_NB) != NB_MAGIC) {             // a new board: an empty notebook
      for (int i = 0; i < NB_N; i++) EEPROM.update(EE_DATA + i, 0xFF);
      for (int i = EE_NB; i < EE_DATA; i++) EEPROM.update(i, 0);
      EEPROM.write(EE_NB, NB_MAGIC);
    }
    EEPROM.get(EE_NB + 1, nbWraps);
    nbHead = 0; while (nbHead < NB_N && EEPROM.read(EE_DATA + nbHead) != 0xFF) nbHead++;
    if (nbHead >= NB_N) nbHead = 0;
    // the time: from the upload if this is a new sketch, otherwise from the last time it wrote down
    uint32_t stamp; EEPROM.get(EE_NB + 3, stamp);
    uint32_t c = compileSeconds();
    if (stamp != c) { _minuteNow = c; _timeApprox = false; EEPROM.put(EE_NB + 3, c); }
    else {
      uint32_t best = 0, v;
      for (uint8_t i = 0; i < 16; i++) { EEPROM.get(EE_SLOT + i * 4, v); if (v > best) best = v; }
      _minuteNow = best ? best : c; _timeApprox = true;
    }
    _millisAtMinute = millis();
  }
  if (!(_chapter == 7 || _chapter == 8 || _chapter == 9 || _chapter == 13)) return;
  // start a new part of the notebook: from here on, records are every WRITE EVERY, from this time
  uint8_t n = nbSegCount();
  Seg s = { nbTotal(), _minuteNow, settings.writeEvery, (uint8_t)(_nbFormat() | (_timeApprox ? 0x80 : 0)) };
  if (n >= NB_SEGS) {                                  // only room for six parts: forget the oldest
    for (uint8_t i = 1; i < NB_SEGS; i++) { Seg t; nbGetSeg(i, t); EEPROM.put(EE_SEG + (i - 1) * 10, t); }
    n = NB_SEGS - 1;
  }
  EEPROM.put(EE_SEG + n * 10, s);
  EEPROM.write(EE_NB + 7, n + 1);
  _lastRecordMs = millis() - (uint32_t)EVERY_SEC(settings.writeEvery) * 1000UL;   // write the first one now
}

void Origins::_nbTick() {
  if (!(_chapter == 7 || _chapter == 8 || _chapter == 9 || _chapter == 13)) return;
  if (!_gotA) return;
  uint32_t every = (uint32_t)EVERY_SEC(settings.writeEvery) * 1000UL;
  if (millis() - _lastRecordMs < every) return;
  _lastRecordMs += every;
  if (millis() - _lastRecordMs > every) _lastRecordMs = millis();
  uint8_t fmt = _nbFormat(), rec[3], n = 0;
  rec[n++] = encodeT(_tA);
  if (fmt & 1) rec[n++] = encodeT(_tB);
  if (fmt & 2) { rec[n++] = _eventsSinceRecord; _eventsSinceRecord = 0; }
  for (uint8_t i = 0; i < n; i++) {
    EEPROM.update(EE_DATA + nbHead, rec[i]);
    if (++nbHead >= NB_N) { nbHead = 0; nbWraps++; EEPROM.put(EE_NB + 1, nbWraps); }
  }
  EEPROM.update(EE_DATA + nbHead, 0xFF);               // marks where the next record goes
}

// LOG: one hour per click. Shows the day, the time, and what was written then.
void Origins::_nbDrawLog() {
  uint32_t total = nbTotal();
  uint32_t oldest = nbWraps ? total - (NB_N - 1) : 0;
  uint8_t ns = nbSegCount();
  // keep the cursor inside the notebook
  if (ns) {
    Seg first; nbGetSeg(0, first);
    if (_logCursor < (int32_t)first.startSec) _logCursor = first.startSec;
    if (_logCursor > (int32_t)_minuteNow) _logCursor = _minuteNow;
  }
  char l0[17], l1[17] = "", l2[17] = "", l3[17] = "";
  uint32_t cur = _logCursor;
  { char dn[4]; strcpy_P(dn, (PGM_P)pgm_read_word(&DAY_NAME[(cur / 86400UL) % 7])); snprintf_P(l0, 17, PSTR("%s %02u:00"), dn, (unsigned)((cur / 3600UL) % 24)); }
  bool found = false;
  for (int8_t i = ns - 1; i >= 0 && !found; i--) {
    Seg s; nbGetSeg(i, s);
    if (cur < s.startSec) continue;
    uint32_t end = total;
    if (i < ns - 1) { Seg t; nbGetSeg(i + 1, t); end = t.startSerial; }
    uint8_t rs = recSize(s.fmt & 3);
    uint32_t k = (cur - s.startSec) / EVERY_SEC(s.every);
    uint32_t pos = s.startSerial + k * rs;
    if (pos + rs > end || pos < oldest) break;          // nothing written for that hour
    uint8_t v[3];
    for (uint8_t j = 0; j < rs; j++) v[j] = EEPROM.read(EE_DATA + (uint16_t)((pos + j) % NB_N));
    char t[8];
    fmtT(t, decodeT(v[0])); snprintf_P(l1, 17, PSTR("A %s"), t);
    if (s.fmt & 1) { fmtT(t, decodeT(v[1])); snprintf_P(l2, 17, PSTR("B %s"), t); }
    if (s.fmt & 2) snprintf_P(l3, 17, PSTR("DOOR %u"), v[rs - 1]);
    if (s.fmt & 0x80) { char m[17]; snprintf_P(m, 17, PSTR("~%s"), l0); strcpy(l0, m); }   // time is approximate after a restart
    found = true;
  }
  _row(0, l0);
  char k[17];
  snprintf_P(k, 17, PSTR("%s"), found ? l1 : "--");
  if (strcmp(k, _rowCache[2]) != 0) { twoBy(2, k); strcpy(_rowCache[2], k); _rowCache[3][0] = 0; }
  _row(5, l2); _row(6, l3);
}
