// MakerNest Origins: the machine from The Maker's Book of Origins.
// One library for every chapter. Each chapter's sketch says which screens it uses
// and writes its own rule in loop(); this library does the dial, the screen,
// the sensors, the memory and the notebook.
//
// MakerNest Origins is a brand of Innointel Global Private Limited.
// makernest.com/origins

#ifndef MAKERNEST_ORIGINS_H
#define MAKERNEST_ORIGINS_H

#include <Arduino.h>
#include <stddef.h>

// ---------------------------------------------------------------- the pins, as printed on the shield
const uint8_t PIN_SENSOR_A = 2;   // sensor A, on the base
const uint8_t PIN_DIAL_CLK = 3;   // the dial
const uint8_t PIN_DIAL_DT  = 4;
const uint8_t PIN_DIAL_SW  = 5;   // pressing the dial
const uint8_t PIN_BUZZER   = 6;
const uint8_t PIN_SENSOR_B = 7;   // sensor B, on its 1 m lead
const uint8_t PIN_DOOR     = 8;   // the door switch, two wires, no power
const uint8_t PIN_LAMP     = 9;   // the switch board for the lamp
const uint8_t PIN_RING     = 11;  // the light ring, 8 lights

// If your buzzer sounds when it should be quiet, change HIGH to LOW here.
#define ORIGINS_BUZZER_ON HIGH

// ---------------------------------------------------------------- colours for the ring
enum RingColour : uint8_t { GREEN = 0, BLUE, WHITE, PURPLE, YELLOW, RING_OFF, RED, ORANGE, COLOUR_COUNT };

// ---------------------------------------------------------------- choices
enum WhenCold : uint8_t { WHEN_RING = 0, WHEN_BUZZER, WHEN_BOTH, WHEN_ALWAYS };
enum StepOutput : uint8_t { STEP_NONE = 0, STEP_RING, STEP_BUZZER, STEP_LAMP };
enum WriteEvery : uint8_t { EVERY_10S = 0, EVERY_1MIN, EVERY_15MIN, EVERY_1H };

const int8_t NOT_SET = -128;

// ---------------------------------------------------------------- the settings, kept in the board's memory
// Every chapter reads the same settings, so a number chosen in chapter 02 is still there in chapter 09.
struct OriginsSettings {
  uint8_t  magic;          // tells the board these settings are ours
  uint8_t  layout;         // version of this list
  int8_t   coldLine;       // WATCH BELOW, later called START. Whole degrees.
  int8_t   stopAt;         // STOP AT. Whole degrees.
  uint8_t  normalColour;   // the ring's colour when everything is fine
  uint8_t  whenCold;       // RING, BUZZER, BOTH or ALWAYS
  uint8_t  apartBy;        // SHOUT IF APART BY, in half degrees. 0 = not chosen yet
  uint8_t  watches;        // ALARM WATCHES: 0 = sensor A, 1 = sensor B
  uint8_t  settle;         // SETTLE, seconds
  uint8_t  keepCount;      // KEEP COUNT AFTER RESTART: 1 yes, 0 no
  uint32_t count;          // the door count
  uint8_t  writeEvery;     // WRITE EVERY
  uint8_t  stepOut[3];     // the sequence: what each step does
  uint8_t  stepFor[3];     //               how long, seconds
  uint8_t  stepGap[3];     //               the gap before it, seconds
  uint8_t  startWith;      // START WITH: 0 nothing, 1 your cold decision
  uint8_t  tooMany;        // TOO MANY openings in an hour. 0 = not chosen yet
  uint8_t  spare[33];
};

// ---------------------------------------------------------------- screens a chapter can use
enum Screen : uint8_t {
  SCR_HOME = 0, SCR_COLD_LINE, SCR_NORMAL_COLOUR, SCR_WHEN_COLD, SCR_TEST, SCR_STOP_AT,
  SCR_APART_BY, SCR_WATCHES, SCR_SETTLE, SCR_KEEP_COUNT, SCR_WRITE_EVERY, SCR_LOG,
  SCR_SEQUENCE, SCR_RUN_NOW, SCR_START_WITH, SCR_TOO_MANY, SCR_COUNT_OF
};

// What the home screen shows
const uint8_t SHOW_A = 1, SHOW_B = 2, SHOW_COUNT = 4, SHOW_LINE = 8, SHOW_NOTEBOOK = 16;

class Origins {
public:
  OriginsSettings settings;

  // chapter: 1 to 12 (13 = Doorkeeper). name: what the display shows at the start.
  void begin(uint8_t chapter, const char *name);
  void useScreen(Screen s);          // add a screen to the dial, in order
  void homeShows(uint8_t what);      // SHOW_A | SHOW_B | ...
  void update();                     // call this first thing in every loop()
  void edit(Screen s);               // open a screen for changing, as if the dial had been pressed on it

  // ---- what the machine knows
  float temperatureA() { return _tA; }   // the last good reading. It never shows an error.
  float temperatureB() { return _tB; }
  float humidityA()    { return _hA; }
  float watchedTemperature() { return settings.watches ? _tB : _tA; }
  bool  haveReading()  { return _gotA; }
  uint32_t count()     { return settings.count; }
  uint8_t openingsInLastHour();
  bool  sequenceRunning() { return _seqStep >= 0; }

  // ---- what it does
  void ring(uint8_t colour);         // all eight lights one colour
  void ringNormal()  { ring(settings.normalColour == 255 ? (uint8_t)GREEN : settings.normalColour); }
  void buzzer(bool on);              // on means on, steadily
  void buzzerBeep(bool on);          // on means beeping, on and off
  void lamp(bool on);
  void runSequence();                // run the three steps once
  void saveSettings();

  // used by the screens
  uint8_t chapter() { return _chapter; }

  // called by the dial interrupt
  void _dialEdge();

private:
  uint8_t _chapter = 1;
  const char *_name = "";
  Screen _screens[16];
  uint8_t _nScreens = 0, _cur = 0;
  bool _editing = false;
  bool _untouched = false;           // a screen opened with nothing chosen yet shows nothing until the dial turns
  int16_t _editValue = 0;
  uint8_t _seqEditIndex = 0;         // 0..8 while editing the sequence
  uint8_t _home = SHOW_A;
  uint32_t _lastSensor = 0, _lastDraw = 0, _lastInput = 0, _doneUntil = 0;
  float _tA = 0, _tB = 0, _hA = 0;
  bool _gotA = false, _gotB = false;
  // dial
  volatile int16_t _dialSteps = 0;
  volatile uint8_t _dialState = 0;
  int16_t _dialTaken = 0;
  bool _btnLast = true; uint32_t _btnTime = 0;
  // door
  bool _doorLast = false; uint32_t _doorIgnoreUntil = 0;
  uint8_t _minuteBuckets[60]; uint8_t _bucketMinute = 0;
  uint8_t _eventsSinceRecord = 0;
  // outputs
  bool _beep = false; bool _buzzSteady = false; uint8_t _ringColour = RING_OFF;
  // sequence
  int8_t _seqStep = -1; uint8_t _seqPhase = 0; uint32_t _seqUntil = 0; bool _seqDoneShow = false;
  // time
  uint32_t _minuteNow = 0;  bool _timeApprox = false; uint32_t _millisAtMinute = 0;  // _minuteNow holds seconds since 1 Jan 2024
  bool _asleep = false;
  // notebook
  uint32_t _lastRecordMs = 0; int32_t _logCursor = 0;
  // display cache
  char _rowCache[8][17];

  void _readDial();
  void _readButton();
  void _readSensors();
  void _readDoor();
  void _tickClock();
  void _tickSequence();
  void _tickOutputs();
  void _draw(bool force);
  void _row(uint8_t r, const char *t);
  void _big(const char *t);
  void _press();
  void _turn(int8_t d);
  void _startEdit();
  void _confirmEdit();
  void _editLimits(Screen s, int16_t &lo, int16_t &hi);
  void _loadSettings(bool reset);
  // notebook
  void _nbBegin();
  void _nbTick();
  uint8_t _nbFormat();
  uint16_t _nbLastsHours(uint8_t every, uint8_t fmt);
  void _nbDrawLog();
  uint8_t _nbFillPercent();
};

extern Origins machine;

#endif
