# MakerNest Origins: the sketches, version 1.1.1

The Arduino library for The Maker's Book of Origins, and every chapter's sketch.

What changed in 1.1.1:

- Sketch 09 (and so chapters 09, 10 and 11) turned the display off after 90 seconds without touching the dial. The book never says so, and chapter 11 depends on the display showing the last good number. The display now stays on.
- From chapter 03, a dial left on a settings screen for five minutes goes back to the reading, and a choice not yet pressed is dropped. Before, a dial left half way through choosing NORMAL COLOUR kept the ring from showing an alarm. The log is left alone (you may be drawing), and so is the first choice a sketch offers on its own.
- Timings are safe across millis() wrapping after 49.7 days of running. Before, a sequence running at that moment cut its steps short, and the door's SETTLE could be skipped once.
- The sequence's third line reads STEP 1 GAP (it was cut to GAP BEFOR).

What changed in 1.1, after the lab's sketch report of November 2026:

- Every chapter's home screen shows three things: the reading, the number the maker is playing with in that chapter, and what the machine decided because of it. Each sketch from chapter 03 on draws its own home screen in a function called whatTheScreenShows(), so the code says exactly what the maker sees.
- The top line is the decision: OK, COLD, ALARM ON, APART, TOO MANY, TOO DAMP. An alarm is shown in reverse.
- The bottom line says what the outputs are doing: RING RED+BEEP, RING BLUE, ORANGE+SIREN, STEP 2 BUZZER 3S. Chapter 09 leaves it out on purpose (see below).
- The buzzer plays notes. A new PITCH screen from chapter 03 (200 to 4000 Hz, the maker hears each number while turning). Cold beeps at your pitch, ALWAYS holds it, A-and-B-apart plays a two-note siren, each door count plays a short higher note, TEST OUTPUTS plays three notes going up.
- Humidity is on the screen from chapter 01.
- Chapter 09 has WATCH FOR: COLD, HOT, DAMP or DRY, with the same START and STOP AT. This is what the book's examples need (a bathroom that stays damp, a bedroom nobody can get cool).
- RESET SETTINGS is the last screen on the dial from chapter 03. The notebook is kept.
- Fixed: the notebook bar overflowed its text and corrupted memory (the "NOTE [#" on the lab photos). SHOUT IF APART BY overflowed the same way; it now shows as SHOUT IF APART on the first line and BY on the second.
- Fixed: choosing NORMAL COLOUR while cold, the ring stayed red. It now shows the colour being chosen.
- RUN NOW goes back to the home screen, so the steps can be watched.

Kept on purpose, as the book teaches it: no error messages and no hints, ever. A sensor that stops answering keeps its last number (chapter 01, fault 5). Chapter 04 still chatters when STOP AT equals START (now the screen counts the switches). Chapter 06 still counts a slow door twice with SETTLE at 0.

Where each sketch lives:
- Chapters 01 and 02: printed in the book (pages 11 and 22). Unchanged in 1.1, so the print still matches. The library draws their screen itself.
- Chapter 03 to the Gift: only on the chapter pages (makernest.com/origins/03 to /12, /d, /g) and from Milo. They are in the folder "Milo sketches".

MakerNest Origins is a brand of Innointel Global Private Limited.

## Install

1. In the Arduino IDE, open Library Manager. Search for MakerNest Origins and install it. When it asks to install other libraries too (U8g2, Adafruit NeoPixel, DHT sensor library), say yes.
2. Until the library is listed in Library Manager, install it from the zip instead: Sketch, Include Library, Add .ZIP Library. Then install the three other libraries from Library Manager by name.
3. Board: Arduino Uno. The kit's board needs the CH340 USB driver (makernest.com/origins/00).

## Hardware this version assumes

- Ring: 8 lights on pin 11.
- Buzzer: a passive buzzer on pin 6, so it can play notes. Notes are made by timer 2, which the kit uses for nothing else.

## What each home screen shows

Rows 0 to 7, 16 letters each.

| Sketch | Top line (decision) | The rest |
|---|---|---|
| 01 First Light | TEMPERATURE | humidity, the big reading |
| 02 The Tripwire | OK or COLD | humidity, big reading, WATCH BELOW 31, ring |
| 03 The Noisemaker | OK or COLD | PITCH 2000 HZ, big reading, BELOW 31 BOTH, ring and buzzer |
| 04 The Chatterbox | ALARM ON or OFF | ON/OFF 14 TIMES, big reading, START 25 STOP 27, outputs |
| 05 Sensor Duel | OK, COLD or APART | A and B tall, GAP NOW, SHOUT OVER, A START25 STOP27, humidity of A and B, outputs |
| 06 The Witness | as 05 | A and B, COUNT and OPEN or SHUT tall, SETTLE, KEEP COUNT, outputs |
| 07 The Night Shift | as 05 | A and B, COUNT and door, WRITE: 10 SEC, notebook (how full, how many readings), outputs |
| 08 Chain Reaction | as 05, SEQUENCE RUNNING, SEQUENCE DONE | A and B, COUNT and door, your three steps, READY, outputs or the step running |
| D The Doorkeeper | as 05, or TOO MANY | A and B, COUNT and door, LAST HOUR 2 OF 3, notebook, outputs |
| 09 Stakeout | OK, TOO COLD, TOO HOT, TOO DAMP, TOO DRY, APART, TOO MANY | A and B (or A and humidity), COUNT and door, DAMP 70% STOP65%, notebook, LAST HOUR. No outputs line: 09 stays on for chapters 10 and 11, and chapter 11 gives no clues. |
| 12 and the Gift | the maker's own | a starter screen for the maker to change |

## Rules every sketch keeps

- Settings live in the board's own memory (EEPROM) in one shared layout, so a number chosen in chapter 02 is still there in chapter 09. Uploading a new sketch never clears them. Version 1.1 uses two spare bytes (PITCH and WATCH FOR); boards set up with 1.0 keep all their settings.
- RESET SETTINGS on the dial, or hold the dial down and press the shield's reset button: every setting goes back to how it came. The notebook is kept.
- The notebook keeps its numbers through uploads and restarts. An upload sets the day and time from the computer. After a restart without an upload, the time continues from the last saved minute and LOG marks it with ~.
- The sensors are read every two seconds, the DHT22's limit.

## Size on the UNO

Every sketch fits with the bootloader (32,256 bytes): from 29.0 KB (chapter 01) to 31.6 KB (chapter 09). RAM: 1.0 to 1.2 KB of 2 KB. Chapter 12 and the Gift leave about 2.4 KB for the maker's own code, enough for several rules; it was 4.5 KB in 1.0, and the notes and new screens took the difference.

## How 1.1 was tested

Every sketch builds for the Uno with avr-gcc and the real U8g2, Adafruit NeoPixel and DHT libraries. Every sketch was also run on a desktop simulation of the board: the real library and the real u8x8 drawing code, with pretend sensors, dial, door and buzzer, and memory checking switched on. The simulation ran the chapters in book order with one shared memory, as a maker's board would. It found and fixed three overflows before release. The expected screens in the lab test card come from that simulation. The lab still has to confirm each one on a real board.

## Before release: bench test (lab)

Use the lab test card: each chapter's steps, the screen to expect, and what the ring and buzzer should do. Also:

1. Each sketch uploads and shows its name for two seconds.
2. Dial direction: clockwise raises the number. If not, swap the CLK and DT wires.
3. Buzzer: quiet at rest. PITCH at 200 Hz sounds low and soft, at 4000 Hz high and sharp. If every note sounds the same, the buzzer is an active one: swap it for a passive one.
4. Chapter 01: pull sensor A's yellow wire. The numbers freeze. Pull the display's red wire. The screen goes dark.
5. Chapter 04: STOP AT equal to START: ON/OFF climbs about every 2 s near the line.
6. Chapter 06: a slow opening adds 2 with SETTLE at 0 (two short notes), and 1 with SETTLE at 2.
7. Chapter 07: at 10 SEC the notebook count rises by one every ten seconds. Unplug and replug: the numbers are still in LOG.
8. Chapter 08: pull the 9 V clip during a run. Steps 1 and 2 run, step 3 does nothing, SEQUENCE DONE shows.
9. RESET SETTINGS, YES: settings return to how they came; LOG still has the week.
10. Chapter 09 on a full battery pack: note how many days it runs (book page 110).

## Notes for makers writing their own code (chapter 12, the Gift)

The library plays notes with the board's timer 2. A sketch that includes MakerNestOrigins should play a note with machine.playNote(hz, ms), not tone(): the two cannot be used together, and the IDE will stop with "multiple definition of __vector_7".
